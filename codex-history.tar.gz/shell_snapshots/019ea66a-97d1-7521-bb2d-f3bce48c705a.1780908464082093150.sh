# Snapshot file
# Unset all aliases to avoid conflicts with functions
# Functions

# setopts 3
set -o braceexpand
set -o hashall
set -o interactive-comments

# aliases 0

# exports 34
declare -x BROWSER="/root/.vscode-server/cli/servers/Stable-8b640eef5a6c6089c029249d48efa5c99adf7d51/server/bin/helpers/browser.sh"
declare -x CODEX_INTERNAL_ORIGINATOR_OVERRIDE="codex_vscode"
declare -x DEBUG="release"
declare -x ELECTRON_RUN_AS_NODE="1"
declare -x HOME="/root"
declare -x HTTPS_PROXY="http://127.0.0.1:7897"
declare -x HTTP_PROXY="http://127.0.0.1:7897"
declare -x LESSCLOSE="/usr/bin/lesspipe %s %s"
declare -x LESSOPEN="| /usr/bin/lesspipe %s"
declare -x LOGNAME="root"
declare -x LS_COLORS=""
declare -x MOTD_SHOWN="pam"
declare -x NODE_TLS_REJECT_UNAUTHORIZED="0"
declare -x NVM_BIN="/usr/local/nvm/versions/node/v16.20.2/bin"
declare -x NVM_CD_FLAGS=""
declare -x NVM_DIR="/usr/local/nvm"
declare -x NVM_INC="/usr/local/nvm/versions/node/v16.20.2/include/node"
declare -x PATH="/root/.codex/tmp/arg0/codex-arg0EcSsY8:/root/.vscode-server/cli/servers/Stable-8b640eef5a6c6089c029249d48efa5c99adf7d51/server/bin/remote-cli:/usr/local/nvm/versions/node/v16.20.2/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin:/root/.vscode-server/extensions/openai.chatgpt-26.602.40724-linux-x64/bin/linux-x86_64"
declare -x RUST_LOG="warn"
declare -x SHELL="/bin/bash"
declare -x SHLVL="2"
declare -x SSH_CLIENT="10.223.103.119 9374 47409"
declare -x SSH_CONNECTION="10.223.103.119 9374 10.176.34.113 47409"
declare -x USER="root"
declare -x VSCODE_AGENT_FOLDER="/root/.vscode-server"
declare -x VSCODE_CLI_REQUIRE_TOKEN="290d939f-ecfe-4871-9394-57d0cb8fea6b"
declare -x VSCODE_CWD="/root"
declare -x VSCODE_ESM_ENTRYPOINT="vs/workbench/api/node/extensionHostProcess"
declare -x VSCODE_HANDLES_SIGPIPE="true"
declare -x VSCODE_HANDLES_UNCAUGHT_ERRORS="true"
declare -x VSCODE_IPC_HOOK_CLI="/tmp/vscode-ipc-15d3116e-e304-47e7-bd01-56252f62757e.sock"
declare -x VSCODE_NLS_CONFIG="{\"userLocale\":\"zh-cn\",\"osLocale\":\"zh-cn\",\"resolvedLanguage\":\"zh-cn\",\"defaultMessagesFile\":\"/root/.vscode-server/cli/servers/Stable-8b640eef5a6c6089c029249d48efa5c99adf7d51/server/out/nls.messages.json\",\"languagePack\":{\"translationsConfigFile\":\"/root/.vscode-server/data/clp/a5e020f199db1fd94e9193b11db5002b.zh-cn/tcf.json\",\"messagesFile\":\"/root/.vscode-server/data/clp/a5e020f199db1fd94e9193b11db5002b.zh-cn/8b640eef5a6c6089c029249d48efa5c99adf7d51/nls.messages.json\",\"corruptMarkerFile\":\"/root/.vscode-server/data/clp/a5e020f199db1fd94e9193b11db5002b.zh-cn/corrupted.info\"},\"locale\":\"zh-cn\",\"availableLanguages\":{\"*\":\"zh-cn\"},\"_languagePackId\":\"a5e020f199db1fd94e9193b11db5002b.zh-cn\",\"_languagePackSupport\":true,\"_translationsConfigFile\":\"/root/.vscode-server/data/clp/a5e020f199db1fd94e9193b11db5002b.zh-cn/tcf.json\",\"_cacheRoot\":\"/root/.vscode-server/data/clp/a5e020f199db1fd94e9193b11db5002b.zh-cn\",\"_resolvedLanguagePackCoreLocation\":\"/root/.vscode-server/data/clp/a5e020f199db1fd94e9193b11db5002b.zh-cn/8b640eef5a6c6089c029249d48efa5c99adf7d51\",\"_corruptedFile\":\"/root/.vscode-server/data/clp/a5e020f199db1fd94e9193b11db5002b.zh-cn/corrupted.info\"}"
declare -x VSCODE_RECONNECTION_GRACE_TIME="10800000"
declare -x _CUDA_COMPAT_PATH="/usr/local/cuda/compat"
